num1 = eval(input())
num2 = eval(input())
num3 = eval(input())
num4 = eval(input())

# TODO



"""
Sum = _
Average = _
"""