def 是否迴文(num):
    位數 = []  # 取出每個位數
    while True:
        餘數 = num % 10
        位數.append(餘數)
        if 餘數 == num:
            break
        else:
            num = (num-位數[-1])//10

    i = -1
    while True:
        i += 1
        j = len(位數)-1-i

        if (i == j) or (i > j):
            break
        if 位數[i] != 位數[j]:
            return False

    return True


def 是否質數(n):
    if n == 1:
        return False
    elif n == 2:
        return True
    else:
        for x in range(2, n):
            if n % x == 0:
                return False

    return True


n = int(input())
lst = []

for x in range(2, n+1):
    if 是否迴文(x) and 是否質數(x):
        lst.append(x)

# row: 輸出到第幾列
# idx: 輸出到第幾個數
# end: 是否已輸出所有數字
row = idx = 0
end = False

while True:
    row += 1
    for i in range(row):
        if (idx+i) >= len(lst):
            end = True
            break
        print("%-4d" % lst[idx+i], end='')

    if end:
        break
    else:
        print()
        idx += row

if idx < len(lst):
    print()

print(sum(lst))
