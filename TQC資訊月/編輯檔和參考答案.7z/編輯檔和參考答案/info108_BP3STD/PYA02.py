num = int(input())

ans = 0
for i in range(1, num+1):
    ans += (-1)**(i+1) / (2*i-1)

print("%.4f" % (4*ans))
