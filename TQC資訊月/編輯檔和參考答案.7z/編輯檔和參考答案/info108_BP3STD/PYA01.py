x = eval(input())
y = eval(input())
z = eval(input())

avg_speed = (z/1.6) / (60*x+y) * 60 * 60
print("Speed = %.1f" % avg_speed)