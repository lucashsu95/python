a = int(input())
b = int(input())

lst = []
for i in range(a, b+1):
    if (i % 4 == 0) and (i % 6 == 0):
        continue
    elif (i % 4 == 0) or (i % 6 == 0):
        lst.append(i)

for i in range(1, len(lst)+1):
    print("%-4d" % lst[i-1], end='')

    if i % 10 == 0:
        print()

if len(lst) % 10:
    print()

print(len(lst))
print(sum(lst))
