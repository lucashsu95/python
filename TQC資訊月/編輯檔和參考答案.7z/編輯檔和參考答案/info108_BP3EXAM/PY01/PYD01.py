x = eval(input())
y = eval(input())
z = eval(input())

# TODO


"""
Speed = _
"""