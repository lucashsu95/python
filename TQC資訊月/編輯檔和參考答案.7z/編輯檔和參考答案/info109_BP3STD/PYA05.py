inp = input()

left, right = [], []    # 放置左、右括弧位置的串列
output = [] # 輸出判斷結果的串列

# 讀取輸入字串，並儲存左右括弧的位置
for i in range(len(inp)):
    if inp[i] == '(':
        left.append(i)
        output.append(' ')
    elif inp[i] == ')':
        right.append(i)
        output.append(' ')
    else:
        output.append('=')

def 配對左括弧(n):
    '''取得配對的右括弧位置(i.e., 右括弧位置中大於 n 的最小位置)
    Args:
        n: 左括弧在字串內的位置
    Return:
        與 n 配對的右括弧位置，若沒有能配對的則回傳 None
    '''
    if len(right) == 0: # 沒有右括弧
        return None
    elif n > right[-1]: # 左括弧位置比所有右括弧都大
        return None
    
    for i in range(len(right)-1, -1, -1):
        if n < right[i]:
            if (i==0) or (n>right[i-1]):
                return right[i]

for x in left[::-1]:    # 從左括弧最大位置開始一一拜訪
    right_idx = 配對左括弧(x)
    
    if right_idx == None:   # 沒有配對的情況
        output[x] = '?'
    else:
        output[x] = output[right_idx] = '*'
        right.remove(right_idx) # 移除已配對的右括弧

for x in right: # 處理沒有配對的右括弧
    output[x] = '?'

for x in output:
    print(x, end='')
