inp = eval(input())


def prime(x):
    '''判斷是否為質數
    Arg:
        x: 正整數
    Return:
        bool: 是否為質數
    '''
    if x == 1:
        return False

    for n in range(2, x):
        if x % n == 0:
            return False
    return True


lst = [inp]  # 儲存運算過程的數字
num = inp
while True:
    # 尋找兩質數總和為 num，且相差最小
    for i in range(num//2, num):
        if prime(i) and prime(num-i):
            diff = i - (num - i)
            lst.append(diff)
            break

    if (diff == 2) or (diff == 0):
        break
    else:
        num = diff

for x in lst:
    print('%d,' % x, end='')
