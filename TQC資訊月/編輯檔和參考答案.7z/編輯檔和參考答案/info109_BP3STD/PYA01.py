num1 = eval(input())
num2 = eval(input())
num3 = eval(input())
num4 = eval(input())
num5 = eval(input())

total_sum = num1 + num2 + num3 + num4 + num5
avg = total_sum / 5

print(num1, num2, num3, num4, num5)
print("Sum = %.1f" % total_sum)
print("Average = %.1f" % avg)
