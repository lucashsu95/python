inp = input()

小寫字母 = 'abcdefghijklmnopqrstuvwxyz'
大寫字母 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

lst = []    # 以串列儲存字母與標點符號出現次數
count = 0
for w in 小寫字母:
    tmp = "{:0>2d}".format(len(小寫字母)-count) + w
    lst.append([0, tmp])
    count += 1


for w in list(inp):
    idx = 小寫字母.find(w)
    if idx == -1:
        idx = 大寫字母.find(w)
        if idx == -1:
            continue

    lst[idx][0] += 1

lst.sort(reverse=True)

top = 5
ans_num = 0
ans_char = ''
for num, char in lst[:top]:
    ans_num += num
    ans_char += char[2:]

print(ans_num)
print(ans_char)
