
inp = input()

# 將輸入轉成二維串列
inp_lst = []
for row in inp.split(','):
    tmp = [int(x) for x in list(row)]
    inp_lst.append(tmp)

num_row = len(inp_lst)      # 取出列數
num_col = len(inp_lst[0])   # 取出行數


def 最大矩形(i, j):     # 找出以 i, j 為左上角的最大矩形面積
    if inp_lst[i][j] == 0:  # (i, j) 的數值為 0
        return 0

    max_area_ij = 0     # 記錄以 i, j 為左上角的最大矩形面積
    max_col = num_col   # 設定最大搜尋行數
    area_ij_lst = [[0]*num_col for _ in range(num_row)]

    for n in range(i, num_row):  # 以先行後列的方式搜尋
        if inp_lst[n][j] == 0:  # 遇到 n 列的第一個數值為 0
            break

        m = j
        while m < num_col:
            if inp_lst[n][m] == 0:  # (n, m) 的數值為 0，設定最大搜尋行數
                max_col = m
                break
            if m >= max_col:
                break  # 不超過最大搜尋行數

            if (m > j) and (n > i):     # 考慮四種情況設定當下的最大矩形面積 area
                area = area_ij_lst[n-1][m]
                area += sum(inp_lst[n][j:m+1])
            elif m > j:
                area = area_ij_lst[n][m-1] + inp_lst[n][m]
            elif n > i:
                area = area_ij_lst[n-1][m] + inp_lst[n][m]
            else:
                area = inp_lst[n][m]

            area_ij_lst[n][m] = area  # 將最大矩形面積 area 寫入二維串列

            if area > max_area_ij:
                max_area_ij = area

            m += 1  # 準備搜尋下一行

    return max_area_ij


max_area = 0
for i in range(num_row):
    for j in range(num_col):
        area = 最大矩形(i, j)

        if area > max_area:
            max_area = area

print(max_area)
