
num = int(input())

lst_num = []    # 存放輸入的數字

for _ in range(num):
    tmp = eval(input())  # 逐一將輸入字串轉成數字
    lst_num.append(tmp)

lst_num.sort()


def 取出整數(x):    # 取出大於或等於 x 的整數
    if x == int(x):  # int(x) 為 x 的整數部分
        return int(x)
    else:
        return int(x)+1


Q1 = lst_num[取出整數(num*1/4) - 1]  # 取出 Q1
Q2 = lst_num[取出整數(num*2/4) - 1]  # 取出 Q2
Q3 = lst_num[取出整數(num*3/4) - 1]  # 取出 Q3

print('%d,%d,%d' % (Q1, Q2, Q3))
