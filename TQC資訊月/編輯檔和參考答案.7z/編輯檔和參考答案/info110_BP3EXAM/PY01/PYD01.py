x = eval(input())
y = eval(input())

# TODO




"""
Inside
Outside
"""